#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
#endregion

namespace NinjaTrader.NinjaScript.Strategies
{
	/// <summary>
	/// Copiador Multicuenta Automatizado para NinjaTrader 8.
	/// Permite replicar ejecuciones desde una cuenta Maestra hacia múltiples cuentas Esclavas.
	/// </summary>
	public class CopiadorCuentasFuturos : Strategy
	{
		#region Properties - Configuración del Copiador
		[NinjaScriptProperty]
		[Display(Name = "Habilitar Copiador", Description = "Activar la replicación automática de órdenes", Order = 1, GroupName = "1. Configuración Copiador")]
		public bool CopierEnabled { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Cuenta Maestra (Master)", Description = "Nombre exacto de la cuenta origen (ej: Sim101, PA_APEX_1)", Order = 2, GroupName = "1. Configuración Copiador")]
		public string MasterAccountName { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Cuentas Esclavas (Slaves)", Description = "Cuentas destino separadas por coma (ej: PA_APEX_2, PA_APEX_3)", Order = 3, GroupName = "1. Configuración Copiador")]
		public string SlaveAccountNames { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Factor de Multiplicación", Description = "Multiplicador de tamaño de contratos para cuentas destino", Order = 4, GroupName = "1. Configuración Copiador")]
		public double Multiplier { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Copiar Entradas", Description = "Replicar órdenes de entrada", Order = 5, GroupName = "1. Configuración Copiador")]
		public bool CopyEntries { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Copiar Salidas / Exits", Description = "Replicar órdenes de salida o cierres", Order = 6, GroupName = "1. Configuración Copiador")]
		public bool CopyExits { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Bloquear Inversión de Posición", Description = "Evitar que las cuentas esclavas abran en dirección contraria", Order = 7, GroupName = "1. Configuración Copiador")]
		public bool BlockPositionInversion { get; set; }
		#endregion

		private List<Account> slaveAccountsList = new List<Account>();

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description							= "Herramienta de replicación y copia de operaciones multicuenta para NinjaTrader 8.";
				Name								= "CopiadorCuentasFuturos";
				Calculate							= Calculate.OnPriceChange;
				IsInstantiatedOnEachOptimizationProperty = false;

				CopierEnabled						= true;
				MasterAccountName					= "Sim101";
				SlaveAccountNames					= "PA_APEX_002, PA_APEX_003";
				Multiplier							= 1.0;
				CopyEntries							= true;
				CopyExits							= true;
				BlockPositionInversion				= true;
			}
			else if (State == State.DataLoaded)
			{
				InitializeSlaveAccounts();
			}
		}

		private void InitializeSlaveAccounts()
		{
			slaveAccountsList.Clear();
			if (string.IsNullOrWhiteSpace(SlaveAccountNames))
				return;

			string[] names = SlaveAccountNames.Split(',');
			lock (Account.All)
			{
				foreach (Account acc in Account.All)
				{
					foreach (string name in names)
					{
						if (acc.Name.Trim().Equals(name.Trim(), StringComparison.OrdinalIgnoreCase))
						{
							slaveAccountsList.Add(acc);
							Print("[COPIADOR] Cuenta Esclava vinculada exitosamente: " + acc.Name);
						}
					}
				}
			}
		}

		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
		{
			if (!CopierEnabled || execution == null || execution.Account == null)
				return;

			// Verificar si la ejecución proviene de la Cuenta Maestra
			if (!execution.Account.Name.Equals(MasterAccountName.Trim(), StringComparison.OrdinalIgnoreCase))
				return;

			int slaveQuantity = (int)Math.Max(1, Math.Round(quantity * Multiplier));

			// Replicar en cada cuenta esclava
			foreach (Account slaveAcc in slaveAccountsList)
			{
				try
				{
					OrderAction action = (execution.Order.OrderAction == OrderAction.Buy || execution.Order.OrderAction == OrderAction.BuyToCover) 
						? OrderAction.Buy 
						: OrderAction.Sell;

					if ((action == OrderAction.Buy || action == OrderAction.Sell) && CopyEntries)
					{
						Order slaveOrder = slaveAcc.CreateOrder(Instrument, action, OrderType.Market, OrderEntry.Manual, TimeInForce.Gtc, slaveQuantity, 0, 0, "", "Copied_Order", DateTime.MaxValue, null);
						slaveAcc.Submit(new[] { slaveOrder });
						Print("[COPIADOR] Orden replicada a cuenta: " + slaveAcc.Name + " | Cantidad: " + slaveQuantity);
					}
				}
				catch (Exception ex)
				{
					Print("[ERROR COPIADOR] Error al replicar en " + slaveAcc.Name + ": " + ex.Message);
				}
			}
		}
	}
}
