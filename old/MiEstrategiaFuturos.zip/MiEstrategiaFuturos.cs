#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
#endregion

namespace NinjaTrader.NinjaScript.Strategies
{
	/// <summary>
	/// Estrategia Automatizada de Futuros con Sistema Integrado de Validación de Cuentas.
	/// </summary>
	public class MiEstrategiaFuturos : Strategy
	{
		#region Private Fields
		private EMA emaFast;
		private EMA emaMid;
		
		private double dailyCumProfit = 0;
		private int tradesTodayCount = 0;
		private DateTime currentTradeDate = DateTime.MinValue;
		private bool dailyPnLocked = false;
		private bool isAccountAuthorized = false;
		#endregion

		#region Properties - 0. Sistema de Licencia y Validación de Cuentas
		[NinjaScriptProperty]
		[Display(Name = "Activar Validación de Cuenta", Description = "Si está activo, solo las cuentas permitidas podrán ejecutar el bot.", Order = 1, GroupName = "0. Licencia & Validación")]
		public bool UseAccountValidation { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Cuentas Autorizadas (separadas por coma)", Description = "Ejemplo: Sim101, PA_APEX_1234, MY_FUNDED_ACCOUNT", Order = 2, GroupName = "0. Licencia & Validación")]
		public string AuthorizedAccountNames { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Fecha Expiración Licencia (YYYYMMDD)", Description = "Formato AAAAMMDD. Ejemplo: 20261231. Usar 0 para sin expiración.", Order = 3, GroupName = "0. Licencia & Validación")]
		public int LicenseExpirationDate { get; set; }
		#endregion

		#region Properties - 1. General & Posición
		[NinjaScriptProperty]
		[Display(Name = "Contratos / Lotes", Order = 1, GroupName = "1. General & Posición")]
		public int Contracts { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Habilitar Compras (Longs)", Order = 2, GroupName = "1. General & Posición")]
		public bool EnableLongs { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Habilitar Ventas (Shorts)", Order = 3, GroupName = "1. General & Posición")]
		public bool EnableShorts { get; set; }
		#endregion

		#region Properties - 2. EMAs & Indicadores
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Período EMA Rápida", Order = 1, GroupName = "2. Indicadores & Tendencia")]
		public int FastPeriod { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Período EMA Media", Order = 2, GroupName = "2. Indicadores & Tendencia")]
		public int MidPeriod { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Mostrar EMAs en Gráfico", Order = 3, GroupName = "2. Indicadores & Tendencia")]
		public bool ShowEMAs { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Usar Filtro Pendiente EMA", Order = 4, GroupName = "2. Indicadores & Tendencia")]
		public bool UseEmaSlopeFilter { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Pendiente Mínima Mid Long (Ticks)", Order = 5, GroupName = "2. Indicadores & Tendencia")]
		public double LongMinMidSlopeTicks { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Usar Filtro de Apilamiento EMA", Order = 6, GroupName = "2. Indicadores & Tendencia")]
		public bool UseEmaStackFilter { get; set; }
		#endregion

		#region Properties - 3. Filtros de Señal
		[NinjaScriptProperty]
		[Display(Name = "Usar Filtro de Cuerpo de Vela", Order = 1, GroupName = "3. Filtros de Señal")]
		public bool UseBaseBodyFilter { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Cuerpo Mínimo de Vela (Ticks)", Order = 2, GroupName = "3. Filtros de Señal")]
		public int BaseMinSignalBodyTicks { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Cuerpo Máximo de Vela (Ticks)", Order = 3, GroupName = "3. Filtros de Señal")]
		public int BaseMaxSignalBodyTicks { get; set; }
		#endregion

		#region Properties - 4. Filtro Horario
		[NinjaScriptProperty]
		[Display(Name = "Hora Inicio Sesión (HHMMSS)", Order = 1, GroupName = "4. Filtro Horario")]
		public int StartTime { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Hora Fin Sesión (HHMMSS)", Order = 2, GroupName = "4. Filtro Horario")]
		public int EndTime { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Cerrar Posición al Finalizar Horario", Order = 3, GroupName = "4. Filtro Horario")]
		public bool ExitAfterEndTime { get; set; }
		#endregion

		#region Properties - 5. Control de Riesgo Diario
		[NinjaScriptProperty]
		[Display(Name = "Usar Bloqueo PnL Diario", Order = 1, GroupName = "5. Control de Riesgo Diario")]
		public bool UseDailyPnLLock { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Pérdida Máxima Diaria ($)", Order = 2, GroupName = "5. Control de Riesgo Diario")]
		public double DailyMaxLossDollars { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Objetivo de Ganancia Diario ($)", Order = 3, GroupName = "5. Control de Riesgo Diario")]
		public double DailyProfitTargetDollars { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Máximo Operaciones por Día", Order = 4, GroupName = "5. Control de Riesgo Diario")]
		public int MaxTradesPerDay { get; set; }
		#endregion

		#region Properties - 6. Stops & Objetivos
		[NinjaScriptProperty]
		[Display(Name = "Long Stop Loss (Ticks)", Order = 1, GroupName = "6. Stops & Objetivos")]
		public int LongStopLossTicks { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Short Stop Loss (Ticks)", Order = 2, GroupName = "6. Stops & Objetivos")]
		public int ShortStopLossTicks { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Long Profit Target (Ticks)", Order = 3, GroupName = "6. Stops & Objetivos")]
		public int LongProfitTargetTicks { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Short Profit Target (Ticks)", Order = 4, GroupName = "6. Stops & Objetivos")]
		public int ShortProfitTargetTicks { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Usar Breakeven", Order = 5, GroupName = "6. Stops & Objetivos")]
		public bool UseBreakeven { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Trigger Breakeven Long (Ticks)", Order = 6, GroupName = "6. Stops & Objetivos")]
		public int LongBreakevenTriggerTicks { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Breakeven Offset Long (Ticks)", Order = 7, GroupName = "6. Stops & Objetivos")]
		public int LongBreakevenPlusTicks { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Usar Trailing Stop", Order = 8, GroupName = "6. Stops & Objetivos")]
		public bool UseTrailingStop { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Trigger Trailing Stop Long (Ticks)", Order = 9, GroupName = "6. Stops & Objetivos")]
		public int LongTrailTriggerTicks { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Distancia Trailing Stop Long (Ticks)", Order = 10, GroupName = "6. Stops & Objetivos")]
		public int LongTrailDistanceTicks { get; set; }
		#endregion

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description							= "Estrategia de trading de futuros personalizada con sistema de validación de licencias y cuentas autorizadas.";
				Name								= "MiEstrategiaFuturos";
				Calculate							= Calculate.OnBarClose;
				IsInstantiatedOnEachOptimizationProperty = true;
				IsExitOnSessionCloseStrategy		= true;
				ExitOnSessionCloseSeconds			= 30;
				BarsRequiredToTrade					= 20;

				// Configuración de Licencia
				UseAccountValidation				= true;
				AuthorizedAccountNames				= "Sim101, PA_APEX_123456, MI_CUENTA_REAL";
				LicenseExpirationDate				= 20261231; // Ejemplo: 31 de Diciembre de 2026

				// Parámetros por Defecto
				Contracts							= 1;
				EnableLongs							= true;
				EnableShorts						= true;

				FastPeriod							= 9;
				MidPeriod							= 21;
				ShowEMAs							= true;
				UseEmaSlopeFilter					= true;
				LongMinMidSlopeTicks				= 0.5;
				UseEmaStackFilter					= true;

				UseBaseBodyFilter					= true;
				BaseMinSignalBodyTicks				= 4;
				BaseMaxSignalBodyTicks				= 40;

				StartTime							= 93000;
				EndTime								= 154500;
				ExitAfterEndTime					= true;

				UseDailyPnLLock						= true;
				DailyMaxLossDollars					= 500;
				DailyProfitTargetDollars			= 1000;
				MaxTradesPerDay						= 5;

				LongStopLossTicks					= 30;
				ShortStopLossTicks					= 30;
				LongProfitTargetTicks				= 60;
				ShortProfitTargetTicks				= 60;

				UseBreakeven						= true;
				LongBreakevenTriggerTicks			= 20;
				LongBreakevenPlusTicks				= 2;

				UseTrailingStop						= true;
				LongTrailTriggerTicks				= 30;
				LongTrailDistanceTicks				= 15;
			}
			else if (State == State.Configure)
			{
				SetStopLoss(CalculationMode.Ticks, LongStopLossTicks);
				SetProfitTarget(CalculationMode.Ticks, LongProfitTargetTicks);
			}
			else if (State == State.DataLoaded)
			{
				// Validar cuenta y licencia al cargar datos
				ValidateAccountAndLicense();

				emaFast = EMA(FastPeriod);
				emaMid = EMA(MidPeriod);

				if (ShowEMAs)
				{
					AddChartIndicator(emaFast);
					AddChartIndicator(emaMid);
				}
			}
		}

		/// <summary>
		/// Sistema de Validación de Licencia por Nombre de Cuenta y Expiración.
		/// </summary>
		private void ValidateAccountAndLicense()
		{
			if (!UseAccountValidation)
			{
				isAccountAuthorized = true;
				return;
			}

			// 1. Verificar Fecha de Expiración
			if (LicenseExpirationDate > 0)
			{
				int todayInt = int.Parse(DateTime.Now.ToString("yyyyMMdd"));
				if (todayInt > LicenseExpirationDate)
				{
					isAccountAuthorized = false;
					Print("[LICENCIA EXPIRADA] La licencia de esta estrategia venció en la fecha: " + LicenseExpirationDate);
					Draw.TextFixed(this, "LicenseError", "ERROR: Licencia Expirada (" + LicenseExpirationDate + ")", TextPosition.Center, Brushes.Red, new Gui.Tools.SimpleFont("Arial", 16), Brushes.Black, Brushes.Red, 100);
					return;
				}
			}

			// 2. Verificar Nombre de la Cuenta Activa
			string currentAccount = Account != null ? Account.Name.Trim() : "";
			string[] allowedAccounts = AuthorizedAccountNames.Split(',');
			bool matchFound = false;

			foreach (string acc in allowedAccounts)
			{
				if (acc.Trim().Equals(currentAccount, StringComparison.OrdinalIgnoreCase))
				{
					matchFound = true;
					break;
				}
			}

			if (!matchFound)
			{
				isAccountAuthorized = false;
				Print("[LICENCIA DENEGADA] La cuenta '" + currentAccount + "' NO está autorizada.");
				Draw.TextFixed(this, "LicenseError", "ACCESO DENEGADO: Cuenta '" + currentAccount + "' no autorizada.", TextPosition.Center, Brushes.Red, new Gui.Tools.SimpleFont("Arial", 16), Brushes.Black, Brushes.Red, 100);
			}
			else
			{
				isAccountAuthorized = true;
				Print("[LICENCIA CORRECTA] Cuenta '" + currentAccount + "' verificada exitosamente.");
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar < BarsRequiredToTrade || !isAccountAuthorized)
				return;

			// Restablecimiento de métricas al cambiar de día
			if (Time[0].Date != currentTradeDate)
			{
				currentTradeDate = Time[0].Date;
				dailyCumProfit = 0;
				tradesTodayCount = 0;
				dailyPnLocked = false;
			}

			if (UseDailyPnLLock && dailyPnLocked)
				return;

			// Filtro Horario
			int timeNow = ToTime(Time[0]);
			if (timeNow < StartTime || timeNow > EndTime)
			{
				if (ExitAfterEndTime && Position.MarketPosition != MarketPosition.Flat)
				{
					if (Position.MarketPosition == MarketPosition.Long) ExitLong();
					else if (Position.MarketPosition == MarketPosition.Short) ExitShort();
				}
				return;
			}

			if (tradesTodayCount >= MaxTradesPerDay)
				return;

			double candleBodyTicks = Math.Abs(Close[0] - Open[0]) / TickSize;
			double midSlope = (emaMid[0] - emaMid[1]) / TickSize;

			// ENTRADA LONG
			if (EnableLongs && Position.MarketPosition == MarketPosition.Flat)
			{
				bool emaTrendOk = !UseEmaStackFilter || (emaFast[0] > emaMid[0]);
				bool slopeOk = !UseEmaSlopeFilter || (midSlope >= LongMinMidSlopeTicks);
				bool bodyOk = !UseBaseBodyFilter || (candleBodyTicks >= BaseMinSignalBodyTicks && candleBodyTicks <= BaseMaxSignalBodyTicks);
				bool pullbackOk = (Low[0] <= emaFast[0] || Low[0] <= emaMid[0]);

				if (emaTrendOk && slopeOk && bodyOk && pullbackOk && Close[0] > Open[0])
				{
					SetStopLoss(CalculationMode.Ticks, LongStopLossTicks);
					SetProfitTarget(CalculationMode.Ticks, LongProfitTargetTicks);
					EnterLong(Contracts, "MiEstrategia_Long");
					tradesTodayCount++;
				}
			}
			// ENTRADA SHORT
			else if (EnableShorts && Position.MarketPosition == MarketPosition.Flat)
			{
				bool emaTrendOk = !UseEmaStackFilter || (emaFast[0] < emaMid[0]);
				bool slopeOk = !UseEmaSlopeFilter || (midSlope <= -LongMinMidSlopeTicks);
				bool bodyOk = !UseBaseBodyFilter || (candleBodyTicks >= BaseMinSignalBodyTicks && candleBodyTicks <= BaseMaxSignalBodyTicks);
				bool pullbackOk = (High[0] >= emaFast[0] || High[0] >= emaMid[0]);

				if (emaTrendOk && slopeOk && bodyOk && pullbackOk && Close[0] < Open[0])
				{
					SetStopLoss(CalculationMode.Ticks, ShortStopLossTicks);
					SetProfitTarget(CalculationMode.Ticks, ShortProfitTargetTicks);
					EnterShort(Contracts, "MiEstrategia_Short");
					tradesTodayCount++;
				}
			}

			// GESTIÓN DE POSICIÓN ABIERTA (Breakeven & Trailing Stop)
			if (Position.MarketPosition != MarketPosition.Flat)
			{
				double openProfitTicks = (Position.MarketPosition == MarketPosition.Long) 
					? (Close[0] - Position.AveragePrice) / TickSize
					: (Position.AveragePrice - Close[0]) / TickSize;

				if (UseBreakeven && openProfitTicks >= LongBreakevenTriggerTicks)
				{
					SetStopLoss(CalculationMode.Ticks, -LongBreakevenPlusTicks);
				}

				if (UseTrailingStop && openProfitTicks >= LongTrailTriggerTicks)
				{
					double trailPrice = (Position.MarketPosition == MarketPosition.Long)
						? Close[0] - (LongTrailDistanceTicks * TickSize)
						: Close[0] + (LongTrailDistanceTicks * TickSize);
					SetStopLoss(CalculationMode.Price, trailPrice);
				}
			}
		}

		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
		{
			if (SystemPerformance.AllTrades.Count > 0)
			{
				Trade lastTrade = SystemPerformance.AllTrades[SystemPerformance.AllTrades.Count - 1];
				dailyCumProfit += lastTrade.ProfitCurrency;

				if (UseDailyPnLLock)
				{
					if (dailyCumProfit <= -Math.Abs(DailyMaxLossDollars) || dailyCumProfit >= DailyProfitTargetDollars)
					{
						dailyPnLocked = true;
					}
				}
			}
		}
	}
}
